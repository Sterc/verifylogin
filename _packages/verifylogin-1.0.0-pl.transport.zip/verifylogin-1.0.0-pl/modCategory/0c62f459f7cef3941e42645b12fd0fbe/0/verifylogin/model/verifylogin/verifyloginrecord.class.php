<?php
/**
 * @package verifylogin
 */
class verifyLoginRecord extends xPDOSimpleObject {}
?>