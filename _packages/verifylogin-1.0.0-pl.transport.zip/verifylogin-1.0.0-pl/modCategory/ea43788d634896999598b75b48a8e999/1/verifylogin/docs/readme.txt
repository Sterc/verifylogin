---------------------------------------
VerifyLogin
---------------------------------------
Version: 1.0.0
Author: Johan van der Molen <johan@sterc.nl>
---------------------------------------

The Verify Login package checks login actions into the manager.
